# -*- coding: utf-8 -*-
"""
Created on Sun Sep  4 16:36:20 2016

@author: jj
"""
import pandas as pd
from numpy import *
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

def random_forest(aaa,EpLable):  
    print 'RF is running'    
    aaa[argwhere(aaa[:,14]==2),14]=0    
    xTrain=zeros((len(aaa)-len(EpLable),10))
    yTrain=[]
    index=0
    for i in argwhere(aaa[:,13]!=2):
        xTrain[index,:]=aaa[i,2:12]
        yTrain.append(float(aaa[i,14]))
        index +=1
    
    xTest=aaa[:,2:12] 
    yTest=[]
    for i in aaa[:,14]:
        yTest.append(i)  
#==============================================================================
#     xTest=zeros((len(EpLable),10))
#     yTest=[]
#     index=0
#     for i in argwhere(aaa[:,13]==2):
#         xTest[index,:]=aaa[i,2:12]
#         yTest.append(float(aaa[i,14]))
#         index+=1
#==============================================================================
    
    md = RandomForestClassifier(n_estimators = 500, n_jobs = 4)
    md.fit(xTrain, yTrain)

    phat = md.predict_proba(xTest)[:,1]
#==============================================================================
#     aaa[:,12]=phat
#==============================================================================
#==============================================================================
#     return phat
#==============================================================================
    return phat
