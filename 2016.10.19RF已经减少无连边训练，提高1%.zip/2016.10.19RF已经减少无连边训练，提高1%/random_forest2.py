# -*- coding: utf-8 -*-
"""
random_forest2
减少无连边的训练，提高1%
"""
import pandas as pd
from numpy import *
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

def random_forest(ttt,EpLable):
    print 'RF is running'  
    ttt[argwhere(ttt[:,14]==2),14]=0    
    NoLinkNum=len(argwhere(ttt[:,14]==1))
    xTrain=zeros((NoLinkNum*2,10))
    yTrain=[]
    index=0
    for i in argwhere(ttt[:,14]==1):
    	xTrain[index,:]=ttt[i,2:12]
    	yTrain.append(1)
    	index +=1
    
    trainarray=argwhere(ttt[:,13]==0)
    random.shuffle(trainarray)
    
    for i in range(0,NoLinkNum):
    	xTrain[index,:]=ttt[trainarray[i],2:12]
    	yTrain.append(0)
    	index +=1
    	
    xTest=ttt[:,2:12] 
    yTest=[]
    for i in ttt[:,14]:
    	yTest.append(i)
    
    md = RandomForestClassifier(n_estimators = 500, n_jobs = 4)
    md.fit(xTrain, yTrain)
    phat2 = md.predict_proba(xTest)[:,1]
    return phat2