# -*- coding: utf-8 -*-
import networkx as nx
import math

def CommonNeighbors(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=len(set(a)&set(b))
                computeredMat.append(length)
        return computeredMat
        
def Salton(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=len(set(a)&set(b))
                finalAns=length/((len(a)*len(b))**0.5)
                computeredMat.append(finalAns)
        return computeredMat
        
def Jaccard(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length1=len(set(a)&set(b))
                length2=float(len(set(a)|set(b)))
                finalAns=length1/length2
                computeredMat.append(finalAns)
        return computeredMat
        
def Sorenson(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=float(2*len(set(a)&set(b)))
                finalAns=length/(len(a)+len(b))
                computeredMat.append(finalAns)
        return computeredMat
        
def HubPromoted(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=float(len(set(a)&set(b)))
                finalAns=length/min(len(a),len(b))
                computeredMat.append(finalAns)
        return computeredMat
        
def HubDepressed(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=float(len(set(a)&set(b)))
                finalAns=length/max(len(a),len(b))
                computeredMat.append(finalAns)
        return computeredMat

def Leicht_Holme_Newman(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)
                length=float(len(set(a)&set(b)))
                finalAns=length/(len(a)*len(b))
                computeredMat.append(finalAns)
        return computeredMat
        
def Preferential_attachment(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                a=G.neighbors(u)
                b=G.neighbors(v)                
                finalAns=len(a)*len(b)
                computeredMat.append(finalAns)
        return computeredMat
        
def Adamic_Adar(G,dataSet):
        computeredMat=[]        
        for u,v in dataSet:
                finalAns=0
                a=G.neighbors(u)
                b=G.neighbors(v) 
                c=set(a)&set(b)
                for i in c:
                        d=float(len(G.neighbors(i)))
                        finalAns+=1/math.log(d)
                computeredMat.append(finalAns)
        return computeredMat
        
def Resource_Allocation(G,dataSet):
        computeredMat=[]
        for u,v in dataSet:
                finalAns=0
                a=G.neighbors(u)
                b=G.neighbors(v) 
                c=set(a)&set(b)
                for i in c:
                        d=float(len(G.neighbors(i)))
                        finalAns+=1/d
                computeredMat.append(finalAns)
        return computeredMat
        


