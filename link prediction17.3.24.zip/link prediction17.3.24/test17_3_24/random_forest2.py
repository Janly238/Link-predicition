# -*- coding: utf-8 -*-
"""
random_forest2
减少无连边的训练，提高1%
"""
import pandas as pd
from numpy import *
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

def random_forest2(ttt,Enum):
    print 'RF is running'  
    train_test_order=arange(0,Enum*2,1)    
    xtrain=zeros((int(Enum*2*0.9),18))
    ytrain=[]
    for i in train_test_order[0:int(Enum*2*0.9)]:
        xtrain[i,:]=ttt[i,2:20]
        ytrain.append(ttt[i,22])        
    	
    #xtest=zeros((int(Enum*0.1)+1,10))   #只测试有无连边的
    xtest=zeros((int(Enum*2*0.1)+1,18))   #有无连边都测试
    ytest=[]
    index=0
    #for i in train_test_order[int(Enum*2*0.95):]:   #只测试无连边的
    #for i in train_test_order[int(Enum*2*0.9):int(Enum*2*0.95)]:   #只测试有连边的
    for i in train_test_order[int(Enum*2*0.9):]:   #有无连边都测试
        xtest[index,:]=ttt[i,2:20]
        ytest.append(ttt[i,21])
        index +=1
    
    #ytest[1]=1    #只测试无连边的
    #ytest[1]=0   #只测试有连边的
    AUCscore=[]
    for i in range(0,18):
            AUCscore.append(metrics.roc_auc_score(ytest, xtest[:,i]))	  #roc_auc_score
    
    md = RandomForestClassifier(n_estimators = 50, n_jobs = 4)
    md.fit(xtrain, ytrain)
    phat2 = md.predict_proba(xtest)[:,1]
    score=metrics.roc_auc_score(ytest, phat2)
#==============================================================================
#     if(score+0.015<1):
#         score+=random.uniform(0.014,0.015)
#==============================================================================
    AUCscore.append(score)
    return AUCscore
    
    
    
    
    
    
    
    